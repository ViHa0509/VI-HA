<?php require_once __DIR__. "/autoload/autoload.php";?>
<?php require_once __DIR__. "/layouts/header.php"; ?>
               <div class="col-md-9 bor">
                  <section class="box-main1">
                     <h3 class="title-main"><a href="">Hệ THống Chi Nhánh</a></h3>
					<div class="main-branch">
            <table width="100%" border="1px" cellpadding="5px" cellspacing="10px" style="background-color: #f2e8d1">
                  <tbody>
                  <tr style="background-color: rgb(230, 126, 34); color: white">
                    <td> <strong style="color: white">Chi nhánh</strong> </td>
                    <td> <strong style="color: white">Tên</strong> </td>
                    <td> <strong style="color: white">Địa chỉ</strong> </td>
                    <td> <strong style="color: white">Điện thoại</strong> </td>
                  </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Cong+ty+Vang+Nu+Trang+Ngoc+Tham+(Ngoc+Tham+Jewelry)/@10.357164,106.375388,15z/data=!4m5!3m4!1s0x0:0xaeb4c3520878069c!8m2!3d10.357164!4d106.375388?hl=vi','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 01 </td>
                        <td class="bgnew3"> Vincom Mega Mall Thảo Điền </td>
                        <td class="bgnew3"> Số 161 Xa lộ Hà Nội, Phường Thảo Điền, Quận 2, TP HCM </td>
                        <td class="bgnew3"> 0941.293.737 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/50+L%C3%AA+V%C4%83n+Vi%E1%BB%87t,+Hi%E1%BB%87p+Ph%C3%BA,+Qu%E1%BA%ADn+9,+H%E1%BB%93+Ch%C3%AD+Minh,+Vietnam/@10.8462523,106.7767523,17z/data=!3m1!4b1!4m5!3m4!1s0x3175270c4901ffbb:0xd1015be42a12eda5!8m2!3d10.846247!4d106.778941','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 03 </td>
                        <td class="bgnew3"> Vincom Plaza Lê Văn Việt </td>
                        <td class="bgnew3"> 50 Lê Văn Việt, Phường Hiệp phú, Quận 9, TP HCM </td>
                        <td class="bgnew3"> 0912.394.646 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Si%C3%AAu+Th%E1%BB%8B+Co.opmart+Sa+%C4%90%C3%A9c/@10.2902582,105.7559971,17z/data=!4m5!3m4!1s0x310a7e40a31cfa95:0x7745410259d7f283!8m2!3d10.2902582!4d105.7581858','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 04 </td>
                        <td class="bgnew3"> Co.opmart Sa Đéc </td>
                        <td class="bgnew3"> 371 Nguyễn Sinh Sắc, Phường 2, TP. Sa Đéc, Đồng Tháp. </td>
                        <td class="bgnew3"> 0949.916.565 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Vincom+Plaza+Xuan+Khanh/@10.0247181,105.7723009,17z/data=!3m1!4b1!4m5!3m4!1s0x31a08820e288dc5b:0x301560920bedaf72!8m2!3d10.0247128!4d105.7744896?hl=en-US','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 05 </td>
                        <td class="bgnew3"> Vincom Plaza Xuân Khánh Cần Thơ </td>
                        <td class="bgnew3"> 209, Đường 30/4, Phường Xuân Khánh, Quận Ninh Kiều, TP. Cần Thơ </td>
                        <td class="bgnew3"> 0917.981.865 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/109+Hai+B%C3%A0+Tr%C6%B0ng,+Ph%C6%B0%E1%BB%9Dng+3,+Tp.+B%E1%BA%A1c+Li%C3%AAu,+B%E1%BA%A1c+Li%C3%AAu,+Vi%E1%BB%87t+Nam/@9.2872908,105.7245075,17z/data=!3m1!4b1!4m5!3m4!1s0x31a1097b062e6e6d:0x6318186068a7dd5e!8m2!3d9.2872908!4d105.7266962','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 06 </td>
                        <td class="bgnew3"> Cửa hàng trang sức Bạc Liêu </td>
                        <td class="bgnew3"> 109 Đường Hai Bà Trưng, Phường 3, TP. Bạc Liêu, Tỉnh Bạc Liêu. </td>
                        <td class="bgnew3"> 0947.496.565 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Co.opmart+T%C3%A2n+An/@10.5349123,106.4087704,17z/data=!3m1!4b1!4m5!3m4!1s0x310ab6249d54c2cf:0xa87c9e02a8d0071b!8m2!3d10.534907!4d106.4109591?hl=en-US','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 07 </td>
                        <td class="bgnew3"> Co.opmart Tân An </td>
                        <td class="bgnew3"> Số 01, Mai Thị Tốt, Phường 2, TP. Tân An, Long An. </td>
                        <td class="bgnew3"> 0919.796.464 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Vincom+Tr%C3%A0+Vinh/@9.9364045,106.3348534,17z/data=!3m1!4b1!4m5!3m4!1s0x31a0175249cffe0d:0x2419fcc45a6f0e2b!8m2!3d9.9363992!4d106.3370421?hl=vi','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 08 </td>
                        <td class="bgnew3"> Vincom Plaza Trà Vinh </td>
                        <td class="bgnew3"> 24 Nguyễn Thị Minh Khai, Phường 2, TP. Trà Vinh </td>
                        <td class="bgnew3"> 0914.804.858 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Vincom+Plaza+V%C4%A9nh+Long/@10.2462645,105.9753227,17z/data=!3m1!4b1!4m5!3m4!1s0x310a9d3138e2b751:0x4553b5bf56c97388!8m2!3d10.2462592!4d105.9775114?hl=vi','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 09 </td>
                        <td class="bgnew3"> Vincom Plaza Vĩnh Long </td>
                        <td class="bgnew3"> Số 55 Phạm Thái Bường, Phường 4, Tp. Vĩnh Long </td>
                        <td class="bgnew3"> 0941.471.177 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Vincom+Plaza+H%E1%BA%ADu+Giang/@9.7835647,105.4677857,17z/data=!3m1!4b1!4m5!3m4!1s0x31a0e93de970647f:0x178e6301ea0b48c2!8m2!3d9.783304!4d105.4703519?hl=en-US','_blank')">
                        <td class="bgnew3"> Chi nhánh - NTJ 10 </td>
                        <td class="bgnew3"> Vincom Plaza Hậu Giang </td>
                        <td class="bgnew3"> Số 01 Đường 3/2, KV3, Phường 5, Tp. Vị Thanh, tỉnh Hậu Giang. </td>
                        <td class="bgnew3"> 0911.884.969 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/C%C3%B4ng+Ty+Tnhh+V%C3%A0ng+B%E1%BA%A1c+%C4%90%C3%A1+Qu%C3%BD+Ng%E1%BB%8Dc+Th%E1%BA%ABm/@10.3557895,106.3765782,16.5z/data=!4m8!1m2!2m1!1sCong+ty+Vang+Nu+Trang+Ngoc+Tham+(Ngoc+Tham+Jewelry)!3m4!1s0x0:0x880ec4540c2247c9!8m2!3d10.3543955!4d106.3741739?hl=vi','_blank')">
                        <td class="bgnew3"> Chi nhánh 01 </td>
                        <td class="bgnew3"> Cửa hàng trang sức Tiền Giang </td>
                        <td class="bgnew3"> 25/2 Nguyễn Huỳnh Đức, Phường 8, TP. Mỹ Tho, Tiền Giang </td>
                        <td class="bgnew3"> (073) 3872 838 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/160+L%C3%AA+Th%E1%BB%8B+H%E1%BB%93ng+G%E1%BA%A5m,+Ph%C6%B0%E1%BB%9Dng+6,+Th%C3%A0nh+ph%E1%BB%91+M%E1%BB%B9+Tho,+Ti%E1%BB%81n+Giang,+Vietnam/@10.3516859,106.3454624,17z/data=!3m1!4b1!4m5!3m4!1s0x310aaff549faeafd:0xcff235c79f5d569b!8m2!3d10.3516806!4d106.3476511','_blank')">
                        <td class="bgnew3"> Chi nhánh 04 </td>
                        <td class="bgnew3"> Cửa hàng trang sức Tiền Giang </td>
                        <td class="bgnew3"> 160C Lê Thị Hồng Gấm, Phường 6, TP. Mỹ Tho, Tiền Giang </td>
                        <td class="bgnew3"> 0918.874.801 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Si%C3%AAu+Th%E1%BB%8B+Co.opmart+M%E1%BB%B9+Tho/@10.3728977,106.3453952,17z/data=!3m1!4b1!4m5!3m4!1s0x310ab0001f99a761:0x3a94f77e876b2abe!8m2!3d10.3728924!4d106.3475839','_blank')">
                        <td class="bgnew3"> Chi nhánh 06 </td>
                        <td class="bgnew3"> Cửa hàng trang sức Tiền Giang </td>
                        <td class="bgnew3"> 35 Ấp Bắc (Co.opmart), Phường 5, TP. Mỹ Tho, Tiền Giang </td>
                        <td class="bgnew3"> 0944.867.511 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Co.opmart+V%C4%A9nh+Long/@10.2550521,105.9683499,17z/data=!3m1!4b1!4m5!3m4!1s0x310a9d2cc83b5881:0xc027fa4026f31261!8m2!3d10.2550468!4d105.9705386','_blank')">
                        <td class="bgnew3"> Chi nhánh 07 </td>
                        <td class="bgnew3"> Cửa hàng trang sức Vĩnh Long </td>
                        <td class="bgnew3"> 26 Đường 3/2 (Co.opmart), TP. Vĩnh Long </td>
                        <td class="bgnew3"> 0944.836.730 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Co.op+Mart+Long+Xuy%C3%AAn/@10.3819761,105.4381406,17z/data=!3m1!4b1!4m5!3m4!1s0x310a72e495a7fce1:0x1b5d814c669e50bf!8m2!3d10.3819708!4d105.4403293','_blank')">
                        <td class="bgnew3"> Chi nhánh 08 </td>
                        <td class="bgnew3"> Cửa hàng trang sức An Giang </td>
                        <td class="bgnew3"> 12A Nguyễn Huệ (Co.opmart), Phường Mỹ Long, TP. Long Xuyên, Tỉnh An Giang </td>
                        <td class="bgnew3"> 0919.940.017 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/33+Ng%C3%B4+Quy%E1%BB%81n,+T%C3%A2n+An,+Ninh+Ki%E1%BB%81u,+C%E1%BA%A7n+Th%C6%A1,+Vietnam/@10.0341583,105.7850093,17z/data=!3m1!4b1!4m5!3m4!1s0x31a062a191df985d:0x17f0793bbc2833b7!8m2!3d10.034153!4d105.787198','_blank')">
                        <td class="bgnew3"> Chi nhánh 09 </td>
                        <td class="bgnew3"> Cửa hàng trang sức Cần Thơ </td>
                        <td class="bgnew3"> 33 Ngô Quyền, Phường Tân An, Quận Ninh Kiều, TP. Cần Thơ </td>
                        <td class="bgnew3"> 0945.437.686 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Trung+tam+Xuc+tien+Dau+tu+Thuong+mai+v%C3%A0+H%E1%BB%99i+ch%E1%BB%A3+tri%E1%BB%83n+l%C3%A3m+(CPA)/@10.0464645,105.781007,17z/data=!4m8!1m2!2m1!1zdHJ1bmcgdMOibSB0aMawxqFuZyBt4bqhaSBuZWFyIFRy4bqnbiBQaMO6LCBwaMaw4budbmcgQ8OhaSBLaOG6vywgQ2FuIFRobywgQ8OhaSBLaOG6vywgcXXhuq1uIE5pbmggS2nhu4F1LCBWaWV0bmFt!3m4!1s0x31a062a165494bcd:0xedc44f3761213a72!8m2!3d10.045143!4d105.783823','_blank')">
                        <td class="bgnew3"> Chi nhánh 10 </td>
                        <td class="bgnew3"> Cửa hàng trang sức Cần Thơ </td>
                        <td class="bgnew3"> 13A1 TTTM Cái Khế, Trần Phú, Phường Cái Khế, Quận Ninh Kiều, TP. Cần Thơ </td>
                        <td class="bgnew3"> 0947.469.399 </td>
                      </tr>
                                        <tr onclick="window.open('https://www.google.com/maps/place/Ti%E1%BB%87m+V%C3%A0ng+Ng%E1%BB%8Dc+Th%E1%BA%ABm/@10.3806404,105.4400703,17z/data=!4m13!1m7!3m6!1s0x310a72fb5639bdd7:0xc9a15a2a45995106!2zMyBOZ3V54buFbiBUcsOjaSwgTeG7uSBMb25nLCBUcC4gTG9uZyBYdXnDqm4sIEFuIEdpYW5nLCBWaWV0bmFt!3b1!8m2!3d10.3806351!4d105.442259!3m4!1s0x310a72fb0982c83b:0x6aaa08bf653a6c5c!8m2!3d10.3822822!4d105.4447067','_blank')">
                        <td class="bgnew3"> Chi nhánh 11 </td>
                        <td class="bgnew3"> Cửa hàng trang sức An Giang </td>
                        <td class="bgnew3"> Số 3 Nguyễn Trãi, Phường Mỹ Long, TP. Long Xuyên, Tỉnh An Giang </td>
                        <td class="bgnew3"> 0919.940.821 </td>
                      </tr>
                                    
            </tbody></table>

        </div>
        <div class="ContentDt" style="padding:0">
        <p style="text-align: center;" style="text-align: center;">
            <img class="ImgReponsive" src="<?php echo base_url()?>public/frontend/images/Chinhanh/ntj-05.jpg" width="100%" height="180"><br> <strong>CN - NTJ05:</strong> Vincom Plaza Xuân Khánh Cần Thơ.</p>
        <p style="text-align: center;" style="text-align: center;">
            <img class="ImgReponsive" src="<?php echo base_url()?>public/frontend/images/Chinhanh/ntj-06.jpg" width="100%" height="180"><br> <strong>CN - NTJ06:</strong> Bạc Liêu, TP. Bạc Liêu.</p>
        <p style="text-align: center;" style="text-align: center;">
            <img class="ImgReponsive" src="<?php echo base_url()?>public/frontend/images/Chinhanh/ntj-07.jpg" width="100%" height="180"><br> <strong>CN - NTJ07:</strong> Co.opmart Long An, TP. Tân An, Long An.</p>
        <p style="text-align: center;" style="text-align: center;">
            <img class="ImgReponsive" src="<?php echo base_url()?>public/frontend/images/Chinhanh/ntj-08.jpg" width="100%" height="180"><br> <strong>CN - NTJ08:</strong> Vincom Plaza Trà Vinh.</p>
 </div>
                     <!-- noi dung -->
                  </section>
               </div>
     <?php require_once __DIR__. "/layouts/footer.php"; ?> 