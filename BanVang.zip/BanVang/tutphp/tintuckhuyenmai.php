<?php require_once __DIR__. "/autoload/autoload.php";?>
<?php require_once __DIR__. "/layouts/header1.php"; ?>
<div class="col-md-9 bor">
    <section class="box-main1">
	</div> <div id="wapperContent" class="bgtrang"> 
    <div class="WapperGroup group">      
        <div class="">
                <h3 style="text-align: center;">Tin khuyến mãi</h3>
        </div>
            <div class="news-top"> 
                <span id="view">
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-uu-dai-len-den-10-mung-dai-le-30-4-va-1-5.html" title="ngọc thẫm jewelry ưu đãi lên đến 10% mừng đại lễ 30/4 và 1/5">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/ngoc-tham-jewelry-uu-dai-len-den-10-mung-dai-le-30-4-va-1-5-thumb-146.jpg" title="ngọc thẫm jewelry ưu đãi lên đến 10% mừng đại lễ 30/4 và 1/5" alt="ngọc thẫm jewelry ưu đãi lên đến 10% mừng đại lễ 30/4 và 1/5" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-uu-dai-len-den-10-mung-dai-le-30-4-va-1-5.html" title="ngọc thẫm jewelry ưu đãi lên đến 10% mừng đại lễ 30/4 và 1/5"><strong>NGỌC THẪM JEWELRY ƯU ĐÃI LÊN ĐẾN 10% MỪNG ĐẠI LỄ 30/4 VÀ 1/5</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 26-04-2018
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ruoc-ngay-dong-vang-ntj-may-man-don-loc-than-tai-cau-nam-dai-thang.html" title="rước ngay đồng vàng ntj may mắn - đón lộc thần tài cầu năm đại thắng">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/ruoc-ngay-dong-vang-ntj-may-man-don-loc-than-tai-cau-nam-dai-thang-thumb.jpg" title="rước ngay đồng vàng ntj may mắn - đón lộc thần tài cầu năm đại thắng" alt="rước ngay đồng vàng ntj may mắn - đón lộc thần tài cầu năm đại thắng" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ruoc-ngay-dong-vang-ntj-may-man-don-loc-than-tai-cau-nam-dai-thang.html" title="rước ngay đồng vàng ntj may mắn - đón lộc thần tài cầu năm đại thắng"><strong>RƯỚC NGAY ĐỒNG VÀNG NTJ MAY MẮN - ĐÓN LỘC THẦN TÀI CẦU NĂM ĐẠI THẮNG</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 10-02-2018
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/vui-xuan-mau-tuat-2018-thoa-suc-nhan-qua-tu-ntj.html" title="vui xuân mậu tuất 2018 - thỏa sức nhận quà từ ntj">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/vui-xuan-mau-tuat-2018-thoa-suc-nhan-qua-tu-ntj-thumb.jpg" title="vui xuân mậu tuất 2018 - thỏa sức nhận quà từ ntj" alt="vui xuân mậu tuất 2018 - thỏa sức nhận quà từ ntj" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/vui-xuan-mau-tuat-2018-thoa-suc-nhan-qua-tu-ntj.html" title="vui xuân mậu tuất 2018 - thỏa sức nhận quà từ ntj"><strong>VUI XUÂN MẬU TUẤT 2018 - THỎA SỨC NHẬN QUÀ TỪ NTJ</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 31-01-2018
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/cung-ntj-chao-don-2018-nhan-uu-dai-len-den-15.html" title="cùng ntj chào đón 2018 - nhận ưu đãi lên đến 15%">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/434 x 300.jpg" title="cùng ntj chào đón 2018 - nhận ưu đãi lên đến 15%" alt="cùng ntj chào đón 2018 - nhận ưu đãi lên đến 15%" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/cung-ntj-chao-don-2018-nhan-uu-dai-len-den-15.html" title="cùng ntj chào đón 2018 - nhận ưu đãi lên đến 15%"><strong>CÙNG NTJ CHÀO ĐÓN 2018 - NHẬN ƯU ĐÃI LÊN ĐẾN 15%</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 30-12-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-tang-qua-xinh-don-noel-2017.html" title="ngọc thẫm jewelry tặng quà xinh đón noel 2017">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/ngoc-tham-jewelry-tang-qua-xinh-don-noel-2017-thumb.jpg" title="ngọc thẫm jewelry tặng quà xinh đón noel 2017" alt="ngọc thẫm jewelry tặng quà xinh đón noel 2017" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-tang-qua-xinh-don-noel-2017.html" title="ngọc thẫm jewelry tặng quà xinh đón noel 2017"><strong>NGỌC THẪM JEWELRY TẶNG QUÀ XINH ĐÓN NOEL 2017</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 21-12-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/mung-black-friday-2017-giam-gia-cuc-lon-tai-ngoc-tham-jewelry.html" title="mừng black friday 2017 giảm giá cực lớn tại ngọc thẫm jewelry">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/mung-black-friday-2017-giam-gia-cuc-lon-tai-ngoc-tham-jewelry-thumb.jpg" title="mừng black friday 2017 giảm giá cực lớn tại ngọc thẫm jewelry" alt="mừng black friday 2017 giảm giá cực lớn tại ngọc thẫm jewelry" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/mung-black-friday-2017-giam-gia-cuc-lon-tai-ngoc-tham-jewelry.html" title="mừng black friday 2017 giảm giá cực lớn tại ngọc thẫm jewelry"><strong>MỪNG BLACK FRIDAY 2017 GIẢM GIÁ CỰC LỚN TẠI NGỌC THẪM JEWELRY</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 18-11-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/uu-dai-10-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-thu-18-tai-bac-lieu.html" title="ưu đãi 10% mừng khai trương chi nhánh ngọc thẫm jewelry thứ 18 tại bạc liêu">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/uu-dai-10-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-thu-18-tai-bac-lieu-thumb.jpg" title="ưu đãi 10% mừng khai trương chi nhánh ngọc thẫm jewelry thứ 18 tại bạc liêu" alt="ưu đãi 10% mừng khai trương chi nhánh ngọc thẫm jewelry thứ 18 tại bạc liêu" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/uu-dai-10-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-thu-18-tai-bac-lieu.html" title="ưu đãi 10% mừng khai trương chi nhánh ngọc thẫm jewelry thứ 18 tại bạc liêu"><strong>ƯU ĐÃI 10% MỪNG KHAI TRƯƠNG CHI NHÁNH NGỌC THẪM JEWELRY THỨ 18 TẠI BẠC LIÊU</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 28-10-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-khuyen-mai-dac-biet-tri-an-phu-nu-viet-nam-dip-20-10.html" title="ngọc thẫm jewelry khuyến mãi đặc biệt tri ân phụ nữ việt nam dịp 20/10">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/NTJ-khuyen-mai-phu-nu-viet-nam-dip-20-10-thum.jpg" title="ngọc thẫm jewelry khuyến mãi đặc biệt tri ân phụ nữ việt nam dịp 20/10" alt="ngọc thẫm jewelry khuyến mãi đặc biệt tri ân phụ nữ việt nam dịp 20/10" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-khuyen-mai-dac-biet-tri-an-phu-nu-viet-nam-dip-20-10.html" title="ngọc thẫm jewelry khuyến mãi đặc biệt tri ân phụ nữ việt nam dịp 20/10"><strong>NGỌC THẪM JEWELRY KHUYẾN MÃI ĐẶC BIỆT TRI ÂN PHỤ NỮ VIỆT NAM DỊP 20/10</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 13-10-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-uu-dai-15-don-mung-quoc-khanh-2-9.html" title="ngọc thẫm jewelry ưu đãi 15% đón mừng quốc khánh 2/9">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/ngoc-tham-jewelry-uu-dai-15-don-mung-quoc-khanh-2-9-thumb.jpg" title="ngọc thẫm jewelry ưu đãi 15% đón mừng quốc khánh 2/9" alt="ngọc thẫm jewelry ưu đãi 15% đón mừng quốc khánh 2/9" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-uu-dai-15-don-mung-quoc-khanh-2-9.html" title="ngọc thẫm jewelry ưu đãi 15% đón mừng quốc khánh 2/9"><strong>NGỌC THẪM JEWELRY ƯU ĐÃI 15% ĐÓN MỪNG QUỐC KHÁNH 2/9</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 26-08-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-uu-dai-dac-biet-tri-an-khach-hang-khi-mua-cac-san-pham-tu-da-swarovski-cao-cap.html" title="ngọc thẫm jewelry ưu đãi đặc biệt tri ân khách hàng khi mua các sản phẩm từ đá swarovski cao cấp">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/NTJ-khuyen-mai-da-swarovski-cao-cap-thumb.jpg" title="ngọc thẫm jewelry ưu đãi đặc biệt tri ân khách hàng khi mua các sản phẩm từ đá swarovski cao cấp" alt="ngọc thẫm jewelry ưu đãi đặc biệt tri ân khách hàng khi mua các sản phẩm từ đá swarovski cao cấp" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-uu-dai-dac-biet-tri-an-khach-hang-khi-mua-cac-san-pham-tu-da-swarovski-cao-cap.html" title="ngọc thẫm jewelry ưu đãi đặc biệt tri ân khách hàng khi mua các sản phẩm từ đá swarovski cao cấp"><strong>NGỌC THẪM JEWELRY ƯU ĐÃI ĐẶC BIỆT TRI ÂN KHÁCH HÀNG KHI MUA CÁC SẢN PHẨM TỪ ĐÁ SWAROVSKI CAO CẤP</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 12-08-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/don-he-lung-linh-rinh-uu-dai-lon-cung-ngoc-tham-jewelry.html" title="đón hè lung linh rinh ưu đãi lớn cùng ngọc thẫm jewelry">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/don-he-lung-linh-rinh-uu-dai-lon-cung-ngoc-tham-jewelry-thumb.jpg" title="đón hè lung linh rinh ưu đãi lớn cùng ngọc thẫm jewelry" alt="đón hè lung linh rinh ưu đãi lớn cùng ngọc thẫm jewelry" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/don-he-lung-linh-rinh-uu-dai-lon-cung-ngoc-tham-jewelry.html" title="đón hè lung linh rinh ưu đãi lớn cùng ngọc thẫm jewelry"><strong>ĐÓN HÈ LUNG LINH RINH ƯU ĐÃI LỚN CÙNG NGỌC THẪM JEWELRY</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 24-06-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/uu-dai-lon-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-tai-vincom-hau-giang.html" title="ưu đãi lớn mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom hậu giang">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/uu-dai-lon-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-tai-vincom-hau-giang-thumb.jpg" title="ưu đãi lớn mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom hậu giang" alt="ưu đãi lớn mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom hậu giang" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/uu-dai-lon-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-tai-vincom-hau-giang.html" title="ưu đãi lớn mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom hậu giang"><strong>ƯU ĐÃI LỚN MỪNG KHAI TRƯƠNG CHI NHÁNH NGỌC THẪM JEWELRY TẠI VINCOM HẬU GIANG</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 19-05-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-khuyen-mai-tung-bung-mung-dai-le-30-4-va-1-5-2017.html" title="ngọc thẫm jewelry khuyến mãi tưng bừng mừng đại lễ 30/4 và 1/5 2017">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/khuyen-mai-30-4-va-1-5-2017-thumb.jpg" title="ngọc thẫm jewelry khuyến mãi tưng bừng mừng đại lễ 30/4 và 1/5 2017" alt="ngọc thẫm jewelry khuyến mãi tưng bừng mừng đại lễ 30/4 và 1/5 2017" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/ngoc-tham-jewelry-khuyen-mai-tung-bung-mung-dai-le-30-4-va-1-5-2017.html" title="ngọc thẫm jewelry khuyến mãi tưng bừng mừng đại lễ 30/4 và 1/5 2017"><strong>NGỌC THẪM JEWELRY KHUYẾN MÃI TƯNG BỪNG MỪNG ĐẠI LỄ 30/4 VÀ 1/5</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 27-04-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/khuyen-mai-tung-bung-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-tai-vincom-plaza-vinh-long.html" title="khuyến mãi tưng bừng mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom plaza vĩnh long">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/khuyen-mai-NTJ-vincom-plaza-vinh-long-thumb.jpg" title="khuyến mãi tưng bừng mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom plaza vĩnh long" alt="khuyến mãi tưng bừng mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom plaza vĩnh long" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/khuyen-mai-tung-bung-mung-khai-truong-chi-nhanh-ngoc-tham-jewelry-tai-vincom-plaza-vinh-long.html" title="khuyến mãi tưng bừng mừng khai trương chi nhánh ngọc thẫm jewelry tại vincom plaza vĩnh long"><strong>KHUYẾN MÃI TƯNG BỪNG MỪNG KHAI TRƯƠNG CHI NHÁNH NGỌC THẪM JEWELRY TẠI VINCOM PLAZA VĨNH LONG</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 24-04-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/uu-dai-10-mung-sinh-nhat-chi-nhanh-ntj-03-vincom-plaza-le-van-viet-quan-9.html" title="ưu đãi 10% mừng sinh nhật chi nhánh ntj-03 vincom plaza lê văn việt quận 9">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/mung-sinh-nhat-chi-nhanh-ntj-03-vincom-plaza-thumb.jpg" title="ưu đãi 10% mừng sinh nhật chi nhánh ntj-03 vincom plaza lê văn việt quận 9" alt="ưu đãi 10% mừng sinh nhật chi nhánh ntj-03 vincom plaza lê văn việt quận 9" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/uu-dai-10-mung-sinh-nhat-chi-nhanh-ntj-03-vincom-plaza-le-van-viet-quan-9.html" title="ưu đãi 10% mừng sinh nhật chi nhánh ntj-03 vincom plaza lê văn việt quận 9"><strong>ƯU ĐÃI 10% MỪNG SINH NHẬT CHI NHÁNH NTJ-03 VINCOM PLAZA LÊ VĂN VIỆT QUẬN 9</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 22-03-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/khuyen-mai-hap-dan-mung-khai-truong-chi-nhanh-ntj-08-vincom-plaza-tra-vinh.html" title="khuyến mãi hấp dẫn mừng khai trương chi nhánh ntj-08 vincom plaza trà vinh">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/khuyen-mai-tra-vinh-2017-thumb.jpg" title="khuyến mãi hấp dẫn mừng khai trương chi nhánh ntj-08 vincom plaza trà vinh" alt="khuyến mãi hấp dẫn mừng khai trương chi nhánh ntj-08 vincom plaza trà vinh" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/khuyen-mai-hap-dan-mung-khai-truong-chi-nhanh-ntj-08-vincom-plaza-tra-vinh.html" title="khuyến mãi hấp dẫn mừng khai trương chi nhánh ntj-08 vincom plaza trà vinh"><strong>KHUYẾN MÃI HẤP DẪN MỪNG KHAI TRƯƠNG CHI NHÁNH NTJ-08 VINCOM PLAZA TRÀ VINH</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 15-03-2017
                                </div>
                                
                            </div>
                        </div>
                     
                        
                        <div class="sub-news col-news">
                            <div class="news-top-left max-height72">
                                <div class="v1-news-item">
                                    <div class="v1-news-item-img">
                                        <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/mua-nu-trang-nhan-ngay-qua-tang-8-3-hap-dan-tu-ntj.html" title="mua nữ trang nhận ngay quà tặng 8/3 hấp dẫn từ ntj">
                                            <img src="http://ngoctham.com.vn/hinh-anh/trang-suc-cuoi/mua-nu-trang-nhan-ngay-qua-tang-8-3-hap-dan-tu-ntj.jpg" title="mua nữ trang nhận ngay quà tặng 8/3 hấp dẫn từ ntj" alt="mua nữ trang nhận ngay quà tặng 8/3 hấp dẫn từ ntj" />
                                        </a>
                                    </div>
                                </div>
                            </div>  
                            <div class="news-top-right max-height72">
                                <h3 class="news-top1-title">
                                    <a href="http://ngoctham.com.vn/tin-tuc/tin-khuyen-mai/mua-nu-trang-nhan-ngay-qua-tang-8-3-hap-dan-tu-ntj.html" title="mua nữ trang nhận ngay quà tặng 8/3 hấp dẫn từ ntj"><strong>MUA NỮ TRANG NHẬN NGAY QUÀ TẶNG 8/3 HẤP DẪN TỪ NTJ</strong></a>
                                </h3>
                                <div class="news-top-datetiem">
                                    Ngày 03-03-2017
                                </div>
                                
                            </div>
                        </div>
                                   </span>
               <div class="Clear"></div>
                      
                        <span id="showPaging">
                            <div class="pagination" > <a title="Next" href="javascript:void(0)" onclick='viewpg("2","24","articles","http://localhost/BanVang/tutphp/tintuckhuyenmai.php","http://ngoctham.com.vn","","18","")'>Xem thêm</a> </div>
                        </span>
  		    </div>

                     <!-- noi dung -->
                  </section>
               </div>
     <?php require_once __DIR__. "/layouts/footer1.php"; ?>  